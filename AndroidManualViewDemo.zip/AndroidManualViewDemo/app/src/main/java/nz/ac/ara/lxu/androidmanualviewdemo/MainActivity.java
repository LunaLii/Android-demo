// https://stackoverflow.com/questions/29047902/how-to-add-an-image-to-the-drawable-folder-in-android-studio
// https://android--code.blogspot.co.nz/2015/09/android-how-to-get-screen-width-and.html
// https://stackoverflow.com/questions/4743116/get-screen-width-and-height
// https://stackoverflow.com/questions/3144940/set-imageview-width-and-height-programmatically

package nz.ac.ara.lxu.androidmanualviewdemo;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import nz.ac.ara.lxu.androidmanualviewdemo.model.Maze;

import static java.lang.Math.round;

public class MainActivity extends AppCompatActivity {

    Maze maze = new Maze();
    ImageView[] imageViews = new ImageView[3];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get the application context
        Context context = getApplicationContext();
        imageViews[0] = findViewById(R.id.imageView);
        imageViews[1] = findViewById(R.id.imageView2);
        imageViews[2] = findViewById(R.id.imageView3);


        /*
            DisplayMetrics
                A structure describing general information about a display,
                such as its size, density, and font scaling.
        */
        DisplayMetrics dm = new DisplayMetrics();
                /*
            WindowManager
                The interface that apps use to talk to the window manager.
                Use Context.getSystemService(Context.WINDOW_SERVICE) to get one of these.
        */

        /*
            public abstract Object getSystemService (String name)
                Return the handle to a system-level service by name. The class of the returned
                object varies by the requested name. Currently available names are:

                WINDOW_SERVICE ("window")
                    The top-level window manager in which you can place custom windows.
                    The returned object is a WindowManager.
        */

        /*
            public abstract Display getDefaultDisplay ()

                Returns the Display upon which this WindowManager instance will create new windows.

                Returns
                The display that this window manager is managing.
        */

        /*
            public void getMetrics (DisplayMetrics outMetrics)
                Gets display metrics that describe the size and density of this display.
                The size is adjusted based on the current rotation of the display.

                Parameters
                outMetrics A DisplayMetrics object to receive the metrics.
        */
        WindowManager windowManager = (WindowManager) context.getSystemService(WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getMetrics(dm);
        for (ImageView imageView : imageViews) {
            imageView.getLayoutParams().width = round(dm.widthPixels / 3);
            imageView.getLayoutParams().height = imageView.getLayoutParams().width;
        }

        for (int i = 0; i < imageViews.length; ++i){
            if ((boolean)(maze.getMap()).get(i)) {
                imageViews[i].setImageResource(R.drawable.image_wall);
            }
        }
        imageViews[maze.getTheseusPos()].setImageResource(R.drawable.image_theseus);

        // imageViews[0].requestLayout();
    }

    public void moveLeft(View view) {
        maze.setTheseusPos(maze.getTheseusPos() - 1);

        for (int i = 0; i < imageViews.length; ++i){
            if ((boolean)(maze.getMap()).get(i)) {
                imageViews[i].setImageResource(R.drawable.image_wall);
            }
        }
        imageViews[maze.getTheseusPos()].setImageResource(R.drawable.image_theseus);
    }
}
