package nz.ac.ara.lxu.androidmanualviewdemo.model;

import java.util.ArrayList;

/**
 * Created by xul on 21/05/2018.
 */

public class Maze {
    private ArrayList map = new ArrayList();
    private int theseusPos;

    public Maze() {
        map.add(true);
        map.add(true);
        map.add(true);
        theseusPos = 2;
    }

    public int getTheseusPos() {
        return theseusPos;
    }

    public void setTheseusPos(int theseusPos) {
        this.theseusPos = theseusPos;
    }

    public ArrayList getMap() {
        return map;
    }
}
