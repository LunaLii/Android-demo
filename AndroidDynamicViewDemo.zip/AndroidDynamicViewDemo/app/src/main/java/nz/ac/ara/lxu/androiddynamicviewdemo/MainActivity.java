// https://stackoverflow.com/questions/40275152/how-to-programmatically-add-views-and-constraints-to-a-constraintlayout
// http://www.zoftino.com/adding-views-&-constraints-to-android-constraint-layout-programmatically
// https://forums.xamarin.com/discussion/8055/unique-id-for-programmatically-created-controls

package nz.ac.ara.lxu.androiddynamicviewdemo;

import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.constraint.ConstraintSet;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ConstraintLayout mainLayout = findViewById(R.id.main_activity_layout);
        TextView textView = new TextView(this);
        textView.setId(R.id.text_msg);
        textView.setText(R.string.msg);
        mainLayout.addView(textView);

        // https://stackoverflow.com/questions/40275152/how-to-programmatically-add-views-and-constraints-to-a-constraintlayout
        // https://developer.android.com/reference/android/support/constraint/ConstraintSet
        ConstraintSet constraintSet = new ConstraintSet();
        constraintSet.clone(mainLayout);
        constraintSet.connect(textView.getId(), ConstraintSet.TOP, mainLayout.getId(), ConstraintSet.TOP, 16);
        constraintSet.connect(textView.getId(), ConstraintSet.END, mainLayout.getId(), ConstraintSet.END, 16);
        constraintSet.constrainHeight(textView.getId(), ConstraintSet.WRAP_CONTENT);
        constraintSet.constrainWidth(textView.getId(), ConstraintSet.WRAP_CONTENT);
        constraintSet.applyTo(mainLayout);

        ImageView imageView = new ImageView(this);
        // https://developer.android.com/reference/android/view/View.html#generateViewId()
        imageView.setId(View.generateViewId());
        imageView.setImageResource(R.drawable.snapchat);

        // https://stackoverflow.com/questions/4743116/get-screen-width-and-height-in-android
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;

        int viewWidth = (int)(width/4);

        imageView.setLayoutParams(new ConstraintLayout.LayoutParams(viewWidth, viewWidth));
        mainLayout.addView(imageView);

        constraintSet.clone(mainLayout);

        constraintSet.connect(imageView.getId(), ConstraintSet.TOP, mainLayout.getId(), ConstraintSet.TOP, 16);
        constraintSet.connect(imageView.getId(), ConstraintSet.END, textView.getId(), ConstraintSet.START, 16);
        constraintSet.applyTo(mainLayout);

    }
}











